package com.lithumc.mixin;

import com.lithumc.config.AbfConfig;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1787;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Prevents fishing rod durability damage when infiniteDurability is enabled.
 *
 * In MC 1.21.4+, FishingRodItem.use() returns InteractionResult (not InteractionResultHolder).
 * We inject at RETURN and reset the rod's damage value to 0 if it was damaged.
 *
 * Modded rod compatibility: covers rods that extend FishingRodItem.
 */
@Mixin(class_1787.class)
public class FishingRodDurabilityMixin {

    @Inject(method = "use", at = @At("RETURN"))
    private void abf$preventDurabilityLoss(class_1937 level, class_1657 player, class_1268 hand,
                                            CallbackInfoReturnable<class_1269> cir) {
        if (!AbfConfig.get().infiniteDurability) return;
        if (level.method_8608()) return;

        class_1799 stack = player.method_5998(hand);
        if (stack.method_7963() && stack.method_7919() > 0) {
            stack.method_7974(0);
        }
    }
}
