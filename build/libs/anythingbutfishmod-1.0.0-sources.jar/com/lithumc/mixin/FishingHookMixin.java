package com.lithumc.mixin;

import com.lithumc.config.AbfConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.List;
import java.util.Optional;
import java.util.Random;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1303;
import net.minecraft.class_1536;
import net.minecraft.class_1542;
import net.minecraft.class_1657;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3417;
import net.minecraft.class_3419;
import net.minecraft.class_3730;
import net.minecraft.class_7923;

/**
 * Mixin targeting FishingHook to replace vanilla fishing loot.
 *
 * Modded rod compatibility: since all fishing hooks (vanilla and modded)
 * use the same net.minecraft.world.entity.projectile.FishingHook class,
 * this mixin automatically covers modded rods that use the vanilla hook entity.
 * The moddedRodCompat config flag is informational.
 */
@Mixin(class_1536.class)
public abstract class FishingHookMixin {

    private static final Logger LOGGER = LoggerFactory.getLogger("anythingbutfish");
    private static final Random RANDOM = new Random();

    @Unique
    private boolean abf$wasInWater = false;

    // -----------------------------------------------------------------------
    // Registry lookup helpers
    // -----------------------------------------------------------------------

    private static Optional<class_1792> resolveItem(String id) {
        if (id == null || id.isBlank()) return Optional.empty();
        return class_7923.field_41178.method_10220()
                .filter(item -> class_7923.field_41178.method_10221(item).toString().equals(id))
                .findFirst();
    }

    private static Optional<class_1299<?>> resolveEntityType(String id) {
        if (id == null || id.isBlank()) return Optional.empty();
        return class_7923.field_41177.method_10220()
                .filter(et -> class_7923.field_41177.method_10221(et).toString().equals(id))
                .findFirst();
    }

    // -----------------------------------------------------------------------
    // HEAD: snapshot in-water state before vanilla runs
    // -----------------------------------------------------------------------

    @Inject(method = "retrieve(Lnet/minecraft/world/item/ItemStack;)I", at = @At("HEAD"))
    private void abf$beforeRetrieve(class_1799 usedItem, CallbackInfoReturnable<Integer> cir) {
        class_1536 self = (class_1536)(Object) this;
        abf$wasInWater = !self.method_73183().method_8608() && self.method_5799();
    }

    // -----------------------------------------------------------------------
    // TAIL: replace loot after vanilla has run
    // -----------------------------------------------------------------------

    @Inject(method = "retrieve(Lnet/minecraft/world/item/ItemStack;)I", at = @At("TAIL"))
    private void abf$afterRetrieve(class_1799 usedItem, CallbackInfoReturnable<Integer> cir) {
        if (!abf$wasInWater) return;
        abf$wasInWater = false;

        AbfConfig cfg = AbfConfig.get();
        if (!cfg.enabled) return;   // master switch

        class_1536 self = (class_1536)(Object) this;
        class_1937 level = self.method_73183();
        if (level.method_8608()) return;

        class_1657 owner = self.method_6947();
        if (!(owner instanceof class_3222 serverPlayer)) return;

        class_3218 serverLevel = (class_3218) level;

        // Remove vanilla-spawned ItemEntities near the bobber
        double bx = self.method_23317(), by = self.method_23318(), bz = self.method_23321();
        serverLevel.method_18467(class_1542.class,
                self.method_5829().method_1014(2.0))
                .forEach(class_1297::method_31472);

        // Play retrieve sound
        level.method_43128(null, bx, by, bz,
                class_3417.field_15093, class_3419.field_15254,
                1.0F, 0.4F / (level.method_8409().method_43057() * 0.4F + 0.8F));

        if (cfg.debugMode)
            LOGGER.info("[AnythingButFish] {} reeled in - generating random loot!", serverPlayer.method_5477().getString());

        spawnRandomLoot(self, serverLevel, serverPlayer, cfg);
    }

    // -----------------------------------------------------------------------
    // Loot dispatch
    // -----------------------------------------------------------------------

    private static void spawnRandomLoot(class_1536 hook, class_3218 level,
                                         class_3222 player, AbfConfig cfg) {
        // cfg.thresholdXp() = chanceItem + chanceEntity + chanceXp (already clamped to 0-100 by AbfConfig.save/load)
        // If all three chances are 0, total = 0 → nothing happens (silent, no sound).
        int total = cfg.thresholdXp();
        if (total <= 0) {
            // All chances are 0: nothing to do, no loot, no sound.
            if (cfg.debugMode) {
                LOGGER.info("[AnythingButFish] All chances are 0 - no loot generated.");
                player.method_64398(class_2561.method_43470("[ABF] All chances are 0 - no loot."));
            }
            return;
        }

        // Roll in range [0, total) so the probability distribution is always correct
        // regardless of whether total < 100 (remainder = "got away") or total == 100 (no got-away).
        int roll = RANDOM.nextInt(total + (100 - total)); // equivalent to nextInt(100), but explicit

        if (roll < cfg.thresholdItem()) {
            spawnItem(hook, level, player, cfg);
        } else if (roll < cfg.thresholdEntity()) {
            spawnEntity(hook, level, player, cfg);
        } else if (roll < cfg.thresholdXp()) {
            spawnExperienceOrbs(hook, level, player, cfg);
        } else {
            // "The one that got away" — roll fell in the [total, 100) gap
            level.method_43128(null, hook.method_23317(), hook.method_23318(), hook.method_23321(),
                    class_3417.field_14660, class_3419.field_15254, 0.25F, 1.0F);
            if (cfg.debugMode) {
                LOGGER.info("[AnythingButFish] The one that got away...");
                player.method_64398(class_2561.method_43470("[ABF] The one that got away..."));
            }
        }
    }

    // -----------------------------------------------------------------------
    // Item drop
    // -----------------------------------------------------------------------

    private static void spawnItem(class_1536 hook, class_3218 level,
                                   class_3222 player, AbfConfig cfg) {
        AbfConfig.ItemEntry entry = cfg.pickRandomItem(RANDOM);
        class_1792 chosen;
        int minCount, maxCount;

        if (entry != null) {
            Optional<class_1792> opt = resolveItem(entry.id);
            if (opt.isEmpty()) {
                LOGGER.warn("[AnythingButFish] Unknown item id '{}', skipping", entry.id);
                return;
            }
            chosen = opt.get();
            minCount = entry.minCount >= 1 ? entry.minCount : cfg.itemCountMin;
            maxCount = entry.maxCount >= minCount ? entry.maxCount : cfg.itemCountMax;
        } else {
            // Full-registry random mode: filter by allowModdedItems
            List<class_1792> allItems = class_7923.field_41178.method_10220()
                    .filter(item -> cfg.allowModdedItems ||
                            "minecraft".equals(class_7923.field_41178.method_10221(item).method_12836()))
                    .toList();
            if (allItems.isEmpty()) return;
            chosen = allItems.get(RANDOM.nextInt(allItems.size()));
            minCount = cfg.itemCountMin;
            maxCount = cfg.itemCountMax;
        }

        int range = maxCount - minCount + 1;
        int count = minCount + (range > 0 ? RANDOM.nextInt(range) : 0);
        class_1799 stack = new class_1799(chosen, count);

        double x = hook.method_23317(), y = hook.method_23318(), z = hook.method_23321();
        class_1542 ie = new class_1542(level, x, y, z, stack);
        applyArc(ie, x, y, z, player, cfg);
        level.method_8649(ie);

        if (cfg.debugMode) {
            String msg = "[ABF] Item: " + class_7923.field_41178.method_10221(chosen) + " x" + count;
            LOGGER.info("[AnythingButFish] {}", msg);
            player.method_64398(class_2561.method_43470(msg));
        }
    }

    // -----------------------------------------------------------------------
    // Entity spawn
    // -----------------------------------------------------------------------

    private static void spawnEntity(class_1536 hook, class_3218 level,
                                     class_3222 player, AbfConfig cfg) {
        AbfConfig.EntityEntry entry = cfg.pickRandomEntity(RANDOM);

        if (entry != null) {
            Optional<class_1299<?>> opt = resolveEntityType(entry.id);
            if (opt.isEmpty()) {
                LOGGER.warn("[AnythingButFish] Unknown entity id '{}', skipping", entry.id);
                return;
            }
            trySpawn(opt.get(), hook, level, player, cfg);
        } else {
            // Full-registry random mode: filter by allowModdedEntities
            List<class_1299<?>> safeTypes = class_7923.field_41177.method_10220()
                    .filter(et -> et != class_1299.field_6097 && et != class_1299.field_6103)
                    .filter(et -> cfg.allowModdedEntities ||
                            "minecraft".equals(class_7923.field_41177.method_10221(et).method_12836()))
                    .toList();
            if (safeTypes.isEmpty()) return;
            trySpawn(safeTypes.get(RANDOM.nextInt(safeTypes.size())), hook, level, player, cfg);
        }
    }

    private static <T extends class_1297> void trySpawn(class_1299<T> type, class_1536 hook,
                                                     class_3218 level, class_3222 player,
                                                     AbfConfig cfg) {
        try {
            T entity = type.method_5883(level, class_3730.field_16462);
            if (entity != null) {
                double x = hook.method_23317(), y = hook.method_23318(), z = hook.method_23321();
                entity.method_5814(x, y, z);
                entity.method_36456(RANDOM.nextFloat() * 360F);
                applyArc(entity, x, y, z, player, cfg);
                level.method_8649(entity);
                if (cfg.debugMode) {
                    String msg = "[ABF] Entity: " + class_7923.field_41177.method_10221(type);
                    LOGGER.info("[AnythingButFish] {}", msg);
                    player.method_64398(class_2561.method_43470(msg));
                }
            }
        } catch (Exception e) {
            LOGGER.warn("[AnythingButFish] Failed to spawn {}: {}", type, e.getMessage());
            try {
                var pig = class_1299.field_6093.method_5883(level, class_3730.field_16462);
                if (pig != null) {
                    pig.method_5814(hook.method_23317(), hook.method_23318(), hook.method_23321());
                    applyArc(pig, hook.method_23317(), hook.method_23318(), hook.method_23321(), player, cfg);
                    level.method_8649(pig);
                }
            } catch (Exception ignored) {}
        }
    }

    // -----------------------------------------------------------------------
    // XP orbs
    // -----------------------------------------------------------------------

    private static void spawnExperienceOrbs(class_1536 hook, class_3218 level,
                                             class_3222 player, AbfConfig cfg) {
        int range = cfg.xpMax - cfg.xpMin + 1;
        int xp = cfg.xpMin + (range > 0 ? RANDOM.nextInt(range) : 0);
        double x = hook.method_23317(), y = hook.method_23318(), z = hook.method_23321();
        class_1303 orb = new class_1303(level, x, y, z, xp);
        applyArc(orb, x, y, z, player, cfg);
        level.method_8649(orb);
        if (cfg.debugMode) {
            String msg = "[ABF] XP: " + xp;
            LOGGER.info("[AnythingButFish] {}", msg);
            player.method_64398(class_2561.method_43470(msg));
        }
    }

    // -----------------------------------------------------------------------
    // Arc velocity helper
    // -----------------------------------------------------------------------

    private static void applyArc(class_1297 entity, double x, double y, double z,
                                  class_3222 player, AbfConfig cfg) {
        double dx = player.method_23317() - x;
        double dy = player.method_23318() - y;
        double dz = player.method_23321() - z;
        entity.method_18800(
                dx * cfg.flingSpeed,
                dy * cfg.flingSpeed + Math.sqrt(Math.sqrt(dx*dx + dy*dy + dz*dz)) * cfg.flingArc,
                dz * cfg.flingSpeed
        );
    }
}
